﻿using System;

namespace RheinwerkAdventure.Model
{
    /// <summary>
    /// Repräsentiert den Helfer am Brunnen.
    /// </summary>
    internal class Decard : Character, IInteractable
    {
        public Decard()
        {
            Texture = "decard.png";
        }
    }
}

