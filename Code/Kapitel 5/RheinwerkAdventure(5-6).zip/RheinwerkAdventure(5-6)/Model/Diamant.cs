﻿using System;

namespace RheinwerkAdventure.Model
{
    internal class Diamant : Item
    {
        public Diamant()
        {
            // Standard-Masse für Diamanten
            Mass = 0.5f;
        }
    }
}

