﻿using System;

namespace RheinwerkAdventure.Model
{
    /// <summary>
    /// Repräsentiert einen Spieler-Charakter.
    /// </summary>
    internal class Player : Character, IAttackable
    {
        public Player()
        {
        }
    }
}

