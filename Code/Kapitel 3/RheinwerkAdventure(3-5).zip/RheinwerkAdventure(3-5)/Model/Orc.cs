﻿using System;

namespace RheinwerkAdventure.Model
{
    /// <summary>
    /// Repräsentiert einen Orc.
    /// </summary>
    internal class Orc : Character, IAttackable
    {
        public Orc()
        {
        }
    }
}

