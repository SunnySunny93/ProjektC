﻿using System;

namespace RheinwerkAdventure.Model
{
    internal class Diamant : Item
    {
        public Diamant()
        {
        }
    }
}

