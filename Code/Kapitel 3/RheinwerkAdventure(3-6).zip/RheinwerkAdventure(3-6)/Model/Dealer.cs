﻿using System;

namespace RheinwerkAdventure.Model
{
    /// <summary>
    /// Repräsentiert den Händler im Spiel.
    /// </summary>
    internal class Dealer : Character, IInteractable
    {
        public Dealer()
        {
        }
    }
}

