﻿using System;

namespace RheinwerkAdventure.Model
{
    /// <summary>
    /// Repräsentiert eine Kachel einer Area.
    /// </summary>
    internal class Tile
    {
        public Tile()
        {
        }
    }
}

